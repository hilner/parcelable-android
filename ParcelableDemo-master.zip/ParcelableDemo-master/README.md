# ParcelableDemo
Transfer name, age, phone number from FirstActivity to SecondActivity by implementing android Parcelable interface.

Screenshot of the App:
![Screenshot_20190422-151244](https://user-images.githubusercontent.com/35850688/56496391-11488b00-651b-11e9-99c9-2572edfbfab7.png)
![Screenshot_20190422-151251](https://user-images.githubusercontent.com/35850688/56496393-11e12180-651b-11e9-9c61-a9a1b5ce2011.png)
